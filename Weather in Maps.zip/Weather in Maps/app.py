from flask import Flask, jsonify
from address_scrapper import fetch_address_from_window

app = Flask(__name__)

# Flask route that triggers the backend function using Selenium to extract the address
@app.route('/run_backend', methods=['POST'])
def run_backend():
    # Call the function from backend.py to extract the address
    address = fetch_address_from_window()
    
    # Return the extracted address to the frontend
    return jsonify({'address': address})

if __name__ == '__main__':
    app.run(debug=True)
